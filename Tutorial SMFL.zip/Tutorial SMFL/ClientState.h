#pragma once

enum ClientState { NONE, PENDING, AUTHENTICATED };
