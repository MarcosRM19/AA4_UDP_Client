#pragma once

enum class NetworkState { DISCONNECTED, CONNECTED_TO_SERVER, CONNECTED_TO_PEERS };